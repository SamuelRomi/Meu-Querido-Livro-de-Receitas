import pytest
import sqlite3
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.receita_dao import ReceitaDAO
from models.receita import Receita, Ingrediente, Preparos

@pytest.fixture
def dao():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.executescript("""
        CREATE TABLE Receita (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            porcao INTEGER,
            tempo_preparo TEXT,
            tipo TEXT,
            preco REAL
        );
        CREATE TABLE usuario_receita (
            usuario_id INTEGER,
            receita_id INTEGER
        );
        CREATE TABLE Ingredientes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            quantidade REAL,
            unidade TEXT,
            id_receita_FK INTEGER
        );
        CREATE TABLE Preparos (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            etapa INTEGER,
            descricao TEXT,
            id_receita_FK INTEGER
        );
    """)
    conn.commit()

    class TestReceitaDAO(ReceitaDAO):
        def get_connection(self):
            return conn

        def inserir(self, receita, ingredientes, preparos, usuario_id):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Receita (nome, porcao, tempo_preparo, tipo, preco)
                VALUES (?, ?, ?, ?, ?)
            """, (receita.nome, receita.porcao, receita.tempo_preparo, receita.tipo, receita.preco))
            receita_id = cursor.lastrowid
            cursor.execute("INSERT INTO usuario_receita (usuario_id, receita_id) VALUES (?, ?)",
                        (usuario_id, receita_id))
            for ing in ingredientes:
                cursor.execute("""
                    INSERT INTO Ingredientes (nome, quantidade, unidade, id_receita_FK)
                    VALUES (?, ?, ?, ?)
                """, (ing.nome, ing.quantidade, ing.unidade, receita_id))
            for prep in preparos:
                cursor.execute("""
                    INSERT INTO Preparos (etapa, descricao, id_receita_FK)
                    VALUES (?, ?, ?)
                """, (prep.etapa, prep.descricao, receita_id))
            conn.commit()

        def listar_por_usuario(self, usuario_id):
            cursor = conn.cursor()
            cursor.execute("""
                SELECT r.id, r.nome, r.porcao, r.tempo_preparo, r.tipo, r.preco
                FROM receita r
                INNER JOIN usuario_receita ur ON r.id = ur.receita_id
                WHERE ur.usuario_id = ?
            """, (usuario_id,))
            receitas_rows = cursor.fetchall()
            receitas_completas = []
            for row in receitas_rows:
                receita = Receita(*row)
                cursor.execute("SELECT * FROM Ingredientes WHERE id_receita_FK = ?", (receita.id,))
                ingredientes_rows = cursor.fetchall()
                ingredientes = [Ingrediente(*ing) for ing in ingredientes_rows]
                cursor.execute("SELECT * FROM Preparos WHERE id_receita_FK = ?", (receita.id,))
                preparos_rows = cursor.fetchall()
                preparos = [Preparos(*p) for p in preparos_rows]
                receitas_completas.append({
                    'receita': receita,
                    'ingredientes': ingredientes,
                    'preparos': preparos
                })
            return receitas_completas

        def atualizar_preco(self, preco, id_receita):
            cursor = conn.cursor()
            cursor.execute("""
                UPDATE Receita
                SET preco = ?
                WHERE id = ?
            """, (preco, id_receita))
            conn.commit()

        def excluir(self, receita_id):
            cursor = conn.cursor()
            cursor.execute("DELETE FROM Ingredientes WHERE id_receita_FK = ?", (receita_id,))
            cursor.execute("DELETE FROM Preparos WHERE id_receita_FK = ?", (receita_id,))
            cursor.execute("DELETE FROM usuario_receita WHERE receita_id = ?", (receita_id,))
            cursor.execute("DELETE FROM Receita WHERE id = ?", (receita_id,))
            conn.commit()

    return TestReceitaDAO()

def test_inserir_e_listar_por_usuario(dao):
    receita = Receita(None, "Lasanha", 4, "60 min", "Almoço", 30.0)
    ingredientes = [Ingrediente(None, "Queijo", 200, "g", None)]
    preparos = [Preparos(None, 1, "Montar em camadas", None)]
    dao.inserir(receita, ingredientes, preparos, usuario_id=1)

    receitas = dao.listar_por_usuario(1)
    assert len(receitas) == 1
    r = receitas[0]
    assert r['receita'].nome == "Lasanha"
    assert r['ingredientes'][0].nome == "Queijo"
    assert r['preparos'][0].descricao == "Montar em camadas"
