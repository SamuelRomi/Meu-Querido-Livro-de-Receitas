import pytest
import sqlite3
import bcrypt
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.usuario_dao import UsuarioDAO, Usuario

@pytest.fixture
def dao():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.executescript("""
        CREATE TABLE Usuario (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT,
            email TEXT,
            senha TEXT
        );
        CREATE TABLE usuario_receita (
            usuario_id INTEGER,
            receita_id INTEGER
        );
    """)
    conn.commit()

    class TestUsuarioDAO(UsuarioDAO):
        def get_connection(self):
            return conn

        def inserir(self, usuario):
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO Usuario (nome, email, senha)
                VALUES (?, ?, ?)
            """, (usuario.nome, usuario.email, usuario.senha))
            conn.commit()

        def buscar_por_email(self, email):
            cursor = conn.cursor()
            cursor.execute("SELECT * FROM Usuario WHERE email = ?", (email,))
            row = cursor.fetchone()
            if row:
                return Usuario(
                    id=row[0],
                    nome=row[1],
                    email=row[2],
                    senha=row[3]
                )
            return None

        def email_existe(self, email):
            cursor = conn.cursor()
            cursor.execute("SELECT 1 FROM Usuario WHERE email = ?", (email,))
            return cursor.fetchone() is not None

    return TestUsuarioDAO()

def test_inserir_e_buscar_por_email(dao):
    senha = bcrypt.hashpw("1234".encode(), bcrypt.gensalt()).decode()
    usuario = Usuario("João", "joao@email.com", senha)
    dao.inserir(usuario)
    achado = dao.buscar_por_email("joao@email.com")
    assert achado.nome == "João"
    assert achado.email == "joao@email.com"

def test_email_existe(dao):
    senha = bcrypt.hashpw("abcd".encode(), bcrypt.gensalt()).decode()
    dao.inserir(Usuario("Luna", "luna@email.com", senha))
    assert dao.email_existe("luna@email.com") is True
    assert dao.email_existe("naoexiste@email.com") is False
