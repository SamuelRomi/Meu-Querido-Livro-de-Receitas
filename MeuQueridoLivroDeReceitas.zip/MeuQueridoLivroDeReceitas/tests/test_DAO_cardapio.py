import pytest
import sqlite3
import os
import sys

sys.path.append(os.path.abspath(os.path.join(os.path.dirname(__file__), '..')))
from dao.cardapio_dao import CardapioDAO

@pytest.fixture
def dao():
    conn = sqlite3.connect(":memory:")
    conn.row_factory = sqlite3.Row
    cursor = conn.cursor()
    cursor.executescript("""
        CREATE TABLE Receita (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nome TEXT
        );
        CREATE TABLE Refeicoes_Cardapio (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            dia_semana TEXT,
            tipo TEXT,
            id_receita_FK INTEGER
        );
        CREATE TABLE Cardapio (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            refeicoes_Cardapio_FK INTEGER,
            id_usuario_FK INTEGER
        );
    """)
    cursor.execute("INSERT INTO Receita (id, nome) VALUES (1, 'Panqueca')")
    conn.commit()

    # Subclasse do DAO para reutilizar a mesma conexão sem fechar
    class TestCardapioDAO(CardapioDAO):
        def get_connection(self):
            return conn
        def adicionar_ao_cardapio(self, dados):
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute(""" 
                INSERT INTO Refeicoes_Cardapio (dia_semana, tipo, id_receita_FK) 
                VALUES (?, ?, ?) 
            """, (dados['dia'], dados['refeicao'], dados['receita_id']))
            id_refeicao = cursor.lastrowid
            cursor.execute(""" 
                INSERT INTO Cardapio (refeicoes_Cardapio_FK, id_usuario_FK) 
                VALUES (?, ?) 
            """, (id_refeicao, dados['usuario_id']))     
            conn.commit()
            return True

        def remover_do_cardapio(self, dados):
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT id FROM Refeicoes_Cardapio
                WHERE dia_semana = ? AND tipo = ? AND id_receita_FK = ?
            """, (dados['dia'], dados['refeicao'], dados['receita_id']))
            resultado = cursor.fetchone()

            if not resultado:
                return False

            id_refeicao = resultado[0]
            cursor.execute("""
                DELETE FROM Cardapio
                WHERE id_usuario_FK = ? AND refeicoes_Cardapio_FK = ?
            """, (dados['usuario_id'], id_refeicao))
            cursor.execute("""
                DELETE FROM Refeicoes_Cardapio
                WHERE id = ?
            """, (id_refeicao,))
            conn.commit()
            return True

        def visualizar_receitas_cardapio(self, usuario_id):
            conn = self.get_connection()
            cursor = conn.cursor()
            cursor.execute("""
                SELECT rc.dia_semana, rc.tipo, rc.id_receita_FK, r.nome
                FROM Cardapio c
                JOIN Refeicoes_Cardapio rc ON c.refeicoes_Cardapio_FK = rc.id
                JOIN Receita r ON r.id = rc.id_receita_FK
                WHERE c.id_usuario_FK = ?
            """, (usuario_id,))
            dados = cursor.fetchall()

            resultado = {dia: {'Café da Manhã': [], 'Almoço': [], 'Jantar': []} for dia in
                        ['Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado', 'Domingo']}

            for row in dados:
                dia_semana = row["dia_semana"]
                tipo_refeicao = row["tipo"]
                id_receita = row["id_receita_FK"]
                nome_receita = row["nome"]
                if dia_semana in resultado and tipo_refeicao in resultado[dia_semana]:
                    resultado[dia_semana][tipo_refeicao].append({'id': id_receita, 'nome': nome_receita})

            return resultado

    return TestCardapioDAO()

def test_adicionar_ao_cardapio(dao):
    dados = {'dia': 'Segunda', 'refeicao': 'Almoço', 'receita_id': 1, 'usuario_id': 1}
    assert dao.adicionar_ao_cardapio(dados)

def test_visualizar_receitas_cardapio(dao):
    dados = {'dia': 'Terça', 'refeicao': 'Jantar', 'receita_id': 1, 'usuario_id': 2}
    dao.adicionar_ao_cardapio(dados)
    resultado = dao.visualizar_receitas_cardapio(2)
    assert resultado['Terça']['Jantar'][0]['nome'] == 'Panqueca'

def test_remover_do_cardapio(dao):
    dados = {'dia': 'Quarta', 'refeicao': 'Café da Manhã', 'receita_id': 1, 'usuario_id': 3}
    dao.adicionar_ao_cardapio(dados)
    assert dao.remover_do_cardapio(dados)
    resultado = dao.visualizar_receitas_cardapio(3)
    assert resultado['Quarta']['Café da Manhã'] == []

def test_remover_refeicao_inexistente(dao):
    dados = {'dia': 'Domingo', 'refeicao': 'Almoço', 'receita_id': 99, 'usuario_id': 5}
    assert dao.remover_do_cardapio(dados) is False
